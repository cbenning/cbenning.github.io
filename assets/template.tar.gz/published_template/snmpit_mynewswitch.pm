U#!/usr/bin/perl -W

#
# EMULAB-LGPL
# All rights reserved.
#

#
# snmpit module for My New Switch
#

package snmpit_mynewswitch;
use strict;

$| = 1; # Turn off line buffering on output

use English;
use SNMP;
use snmpit_lib;
use libtestbed;


#
# All functions are based on snmpit_nortel class.
#

#
# Creates a new object.
#
# usage:	new($classname,$devicename,$debuglevel,$community)
#	    	returns a new object to be passed around as a reference
#			to the current session
#
sub new($classname,$devicename,$debuglevel,$community) {

	##The return value here should be an object that all other functions 
	##will be given as the first parameter by emulab.
}


#
# Set a variable associated with a port. The commands to execute are given
#
# usage: portControl($self, $command, @ports)
#	 returns 0 on success.
#	 returns number of failed ports on failure.
#	 returns -1 if the operation is unsupported
#
sub portControl($self, $command, @ports) {

	#Used primarily for setting things like port duplex, speed, etc.
}


#
# Given VLAN indentifiers from the database, finds the 802.1Q VLAN
# number for them. If no VLAN id is given, returns mappings for the entire
# switch.
# 
# usage: findVlans($self, @vlan_ids)
#        returns a hash mapping VLAN ids to ... VLAN ids.
#        any VLANs not found have undef VLAN numbers
#
sub findVlans($self, @vlan_ids) { 

}


#
# See the comments of findVlans above for explanation.
#
# usage: findVlan($self, $vlan_id,$no_retry)
#        returns the VLAN number for the given vlan_id if it exists
#        returns undef if the VLAN id is not found
#
sub findVlan($self, $vlan_id,$no_retry) { 

}

# 
# Check to see if the given 802.1Q VLAN tag exists on the switch
#
# usage: vlanNumberExists($self, $vlan_number)
#        returns 1 if the VLAN exists, 0 otherwise
#
sub vlanNumberExists($self, $vlan_number){
	
}


#   
# Create a VLAN on this switch, with the given identifier (which comes from
# the database) and given 802.1Q tag number
#
# usage: createVlan($self, $vlan_id, $vlan_number)
#        returns the new VLAN number on success
#        returns 0 on failure
#
sub createVlan($self, $vlan_id, $vlan_number) {
   
}


#
# Puts ports in the VLAN with the given identifier. 
#
# usage: setPortVlan($self, $vlan_number, @ports)
#	 returns 0 on sucess.
#	 returns the number of failed ports on failure.
#
sub setPortVlan($self, $vlan_number, @ports) {

}


#
# Remove the given ports from the given VLAN. The VLAN is given as an 802.1Q 
# tag number.
# usage: delPortVlan($self, $vlan_number, @ports)
#	 returns 0 on sucess.
#	 returns the number of failed ports on failure.
#
sub delPortVlan($self, $vlan_number, @ports) {

}

#
# Disables all ports in the given VLANS. Each VLAN is given as a VLAN
# 802.1Q tag number.
#
# usage: removePortsFromVlan($self,@vlan)
#	 returns 0 on sucess.
#	 returns the number of failed ports on failure.
#
sub removePortsFromVlan($self,@vlan) {
    
}

#
# Removes and disables some ports in a given VLAN.
# The VLAN is given as a VLAN 802.1Q tag number.
#
# This function is the same to delPortVlan AFAIK
#
# usage: removeSomePortsFromVlan($self,$vlan,@ports)
#	 returns 0 on sucess.
#	 returns the number of failed ports on failure.
#
sub removeSomePortsFromVlan($self,$vlan_num,@ports) {
		
}

#
# Remove the given VLANs from this switch. Removes all ports from the VLAN,
# The VLAN is given as a VLAN identifier from the database.
#
# usage: removeVlan($self, $vlan_num)
#	 returns 1 on success
#	 returns 0 on failure
#
sub removeVlan($self, $vlan_num) {
    
}

#
# Determine if a VLAN has any members 
# (Used by stack->switchesWithPortsInVlan())
#
# usage: vlanHasPorts($self, $vlan_num)
#	returns 1 if vlan has assigned ports
#	returns 0 otherwise
#
sub vlanHasPorts($self, $vlan_num) {
    
}

#
# List all VLANs on the device
#
# usage: listVlans($self)
# returns: A list of VLAN information. Each entry is an array reference. The
#   array is in the form [$id, $ddep, $members] where:
#	id is the VLAN identifier, as stored in the database 
#	ddep is an opaque string that is device-dependant (mostly for debugging purposes)
#   members is a reference to an array of VLAN members (ports)
#
sub listVlans($self) {

}

#
# List all ports on the device
#
# usage: listPorts($self)
# returns: A list of port information. Each entry is an array reference. The
#   array is in the form [id, enabled, link, speed, duplex] where:
#       id is the port identifier (in node:port form)
#       enabled is "yes" if the port is enabled, "no" otherwise
#       link is "up" if the port has carrier, "down" otherwise
#       speed is in the form "XMbps"
#       duplex is "full" or "half"
#
sub listPorts($self) {
    
}

# 
# Get statistics for ports on the switch
#
# usage: getStats($self)
# see snmpit_cisco_stack.pm for a description of return value format
#
sub getStats() {

}


#
# Get the ifindex for an EtherChannel (trunk given as a list of ports)
#
# usage: getChannelIfIndex($self, @ports)
#        Returns: 	undef if more than one port is given, and no channel is found
#           		an ifindex if a channel is found and/or only one port is given
#
sub getChannelIfIndex($self, @ports) {

}


#
# Enable, or disable,  port on a trunk
#
# usage: setVlansOnTrunk($self, $modport, $value, @vlan_numbers)
#    	    modport: module.port of the trunk to operate on
#    	    value: 0 to disallow the VLAN on the trunk, 1 to allow it
#    		vlan_numbers: An array of 802.1Q VLAN numbers to operate on
#
#        Returns 1 on success, 0 otherwise
#
sub setVlansOnTrunk($self, $modport, $value, @vlan_numbers) {

}

#
# Enable trunking on a port
#
# usage: enablePortTrunking2($self, $modport, $nativevlan, $equaltrunking)
#        modport: module.port of the trunk to operate on
#        nativevlan: VLAN number of the native VLAN for this trunk
#	 	 equaltrunk: don't do dual mode; tag PVID also.
#        Returns 1 on success, 0 otherwise
#
sub enablePortTrunking2($self, $modport, $nativevlan, $equaltrunking) {

}

#
# Disable trunking on a port
#
# usage: disablePortTrunking($self, $modport)
#        modport: module.port of the trunk to operate on
#        Returns 1 on success, 0 otherwise
#
sub disablePortTrunking($self, $modport) {

}



# End with true
1;
