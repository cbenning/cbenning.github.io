#!/usr/bin/perl
use strict;
use snmpit_mynewswitch;

#Create new Session
my $obj = snmpit_mynewswitch::new("switch","mynewswitch_db_ident",2,"public_community_name");

#Set some desired ports to full duplex 1GB connection
my @ports = (21,22,4,13,9);
my $result = snmpit_mynewswitch::portControl($obj,"full1000mbit",@ports);

#Check it the change happened
my @info = snmpit_mynewswitch::listPorts($obj);

foreach my $sublist (@info){
	foreach my $item (@$sublist){
		print $item." ";
	}
	print "\n"
}

#Create a new Vlan
my $result = snmpit_mynewswitch::createVlan($obj,"Port Test 2",18);
#get a list of vlans and show them
my @info = snmpit_mynewswitch::listVlans($obj);
foreach my $vlan (keys %vlans){
	print $vlan." \n";
}


